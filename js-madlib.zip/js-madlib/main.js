
// Event Listener
document.getElementById('madlib-btn').addEventListener("click", displayMessage)


//Event Fucntion
function displayMessage() {
    // Input
    let verb = document.getElementById('v-input').value;
    let pluralNoun = document.getElementById('p-input').value;
    let adjective = document.getElementById('a-input').value;
    let present = document.getElementById('present-input').value;
    let noun = document.getElementById('n-input').value;
    
    // Build a message
    let message = '"There are too many ' + verb +  ' '  + pluralNoun + ' on this ' + adjective + ' airplane! , I screamed.  “Somebody has to ' + present + ' on the ' + noun + ' to solve this problem!"';
    
    // Output the Message
    document.getElementById('output').innerHTML = message;
    document.getElementById("output").style.borderStyle = "solid";
}

